Copyright (c) 2000-2002 EUROCONTROL, all rights reserved.
This work is subject to the license provided in the file LICENSE.txt.

eAIP splitter and identity transforms
=====================================

These XSLT transformation stylesheets can be very handy when dealing with the eAIP. 

identity.xslt is an "identity transformation": it copies all the nodes from a source XML document into the target XML document.

Why is it useful?
It can be used to reassemble a split eAIP into a single file-eAIP, for instance. It is also used by the eAIP splitter.

eAIP-splitter.xslt is a custom XML document splitter. It copies all the nodes from a source XML document into a set of target XML files. Certain pre-defined elements will be copied into a separate file. A master file will be created with external entity references to include the separate files. If you don't like our way of splitting the source document, you can customise it to fit your own needs. The eAIP file naming convention is respected for target files.

Why is it useful?
When DTD or generic XML changes arise, an XSLT transformation can usually be written to transform eAIP XML documents and apply those changes. Such a transformation will produce a single-file eAIP document in XML. The splitter can be used afterwards to re-split the eAIP.

Requirements
------------
eAIP-splitter.xslt only works with the Xalan XSLT processor, as it makes use of Xalan extensions.

The source eAIP needs to have a DOCTYPE declaration, which must declare the id attributes as of type ID.

Limitations and remarks
-----------------------
1) Doctype
The identity transform will not copy the DOCTYPE declaration (there is no way to read the DOCTYPE declaration in XSLT). Instead, it creates the official DOCTYPE for the eAIP, which you may want to change manually.

2) Character set
Both transforms are set to output XML documents in UTF-8 character set. This must be changed manually in the code if necessary.

A consequence of using UTF-8 is that the transforms will convert named character entities into their actual character value. If you use a Unicode-capable operating system (such as Windows NT4/2000/XP and some Unix systems), then you don't need to worry about UTF-8 characters: you will see them just as "normal" characters. Otherwise, you need to replace UTF-8 by a character set that your operating system understands (for example, in Western Europe it is ISO-8859-1). If you use anything else then UTF-8 then all characters that do not belong to your chosen character-set will be converted to numeric character entities.

For example, Slovenian language makes use of the lower case s letter with a caron. Its named character reference is "&scaron;" and its numeric character reference is "&#x0161;" (in hexadecimal). Both character references relate to the exact same character. This letter is part of character set ISO-8859-2. If the output character set is ISO-8859-1, this letter will be output as "&#x0161;", even if it is written as "&scaron;" in the source document. If the output character set is either UTF-8 or iso-8859-2, this letter will be output as a "normal" character (an s with caron), even if it is written as "&scaron;" (or "&#x0161;") in the source document.

