Drop in this directory the public keys of the eAIP producers, then run
sigcheck -pgp -import
