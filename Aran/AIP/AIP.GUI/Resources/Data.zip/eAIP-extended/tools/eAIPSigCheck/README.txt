********************************
 eAIP Signature Checker
 copyright 2003 Eurocontrol 
 Author: Benoit Maisonny

License:

 This product includes software developed by the OpenSSL Project
 for use in the OpenSSL Toolkit. (http://www.openssl.org/)


The licenses are located in the respective installation directories.

********************************

