********************************
 eAIP Signer
 copyright 2003 Eurocontrol 
 Author: Benoit Maisonny

License:

This package contains the following free software:

  OpenSSL

The licenses are located in the respective installation directories.

********************************

Usage:

Put PEM certificate in Cetrtificate directory.
Put PEM private key in PrivateKey directory.

sign file_to_sign

See the eAIP security manual for more details.
