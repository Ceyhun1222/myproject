#!/bin/bash
# This script remove everything frim the index!

# SOLR_SERVER example: http://localhost:8080/Search
SOLR_SERVER=http://localhost:8080/Search

curl "${SOLR_SERVER}/update/?commit=true" -H "Content-Type: text/xml" --data-binary '<delete><query>*:*</query></delete>'
