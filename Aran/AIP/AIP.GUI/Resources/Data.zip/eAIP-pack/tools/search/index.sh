#!/bin/bash

# SOLR_SERVER example: http://localhost:8080/Search
SOLR_SERVER=http://localhost:8080/Search

# Index method.
index() {
  for i in "$1"/*
  do
    if [ -d "$i" ];then
      index "$i"
    elif [ -f "$i" ]; then
      # Index only HTML files.
      if [ "${i##*.}" == "html" ]; then
	echo "indexing: ${i%}" 
	curl "${SOLR_SERVER}/update/extract?literal.id=${i%}&commit=true" -F "myfile=@${i%}"
      fi
    fi
  done
}

# HELP
if [ "$1" == "--help" -o "$1" == "-h" ]; then
  echo "Give the directory to index. All files located in this directory and all its sub-directories will be indexed."
  echo "Example: ./index.sh PATH_TO_DIRECTORY"
  echo ""
  exit
fi

# Check that argument is a directory.
if [ -d $1 ]; then
  echo "Argument is directory: OK"
else
  echo ${1} " is not a directory"
  exit
fi

# Ask confirmation before indexing
# echo "This script is designed to index the html directory"
echo "Are you sure you want to index all files located in '"$1"' and its sub-directories? y/n"
read CONFIRM

if [ "${CONFIRM}" == "n" -o "${CONFIRM}" == "no" ]
then
  echo "Operation aborted"
  exit

elif [ "${CONFIRM}" != "y" -a "${CONFIRM}" != "yes" ]
then
  echo "Wrong confirmation: must be 'yes', 'y','no' or 'n'!"
  echo "Operation aborted"
  exit

fi

# INDEX FILES
echo "Start indexing..."
index "$1";
echo "Done."