function show_hide(elemid) {
	var el = document.getElementById(elemid);
	
	if (el.style.display != "none") {
		el.style.display = "none";
	} else {
		el.style.display = "";
	}
}

var toc;

function open_toc(file) {
  toc = window.open(file, 'eAIPNavigation', 
      'height=300,width=500,resizable=yes,location=no,directories=no,menubar=yes,toolbar=no,scrollbars=yes');
  toc.focus();
}
