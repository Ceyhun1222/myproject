/*
	doc.js: script for the DTD documentation
	$Date: 2003-01-25 16:51:30 +0100 (Sat, 25 Jan 2003) $
	$Revision: 2754 $
*/

// global constants
var HIDE = 0;
var SHOW = 1;
var TOGGLE = 3;

function doc_border(acr, operation) {
  var op;
  var elem = acr.parentNode;

  if (operation == TOGGLE) {
    if (elem.style.backgroundColor == "" || elem.style.backgroundColor == "transparent") {
      op = SHOW;
    } else {
      op = HIDE;
    }
  } else {
    op = operation;
  }

  if (op == SHOW) {
    elem.style.backgroundColor = "#dddddd";
  } else {
    elem.style.backgroundColor = "transparent";
  }
  return 1;
}
