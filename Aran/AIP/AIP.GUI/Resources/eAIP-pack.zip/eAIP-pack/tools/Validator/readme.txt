The eAIP-validator.xslt transformation can be used to validate an eAIP against rules that connot be enforced by the DTD.

Copyright (c) 2000-2002 EUROCONTROL, all rights reserved.
This work is subject to the license provided in the file LICENSE.txt.

Usage:
------
Call the transformation with your favourite XSLT processor on the eAIP you want to validate. The transformation outputs an XML document containing errors and warnings, and for each of them, a brief message explaining the issue and a pointer to the offending element or attribute.

Warnings can be turned off by calling the transformation with the parameter "WARNINGS" set to "OFF".

Note: not all rules are implemented yet.

MakeAIP.bat
-----------
The validator is integrated with MakeAIP.bat using the file validator.bat. This batch file will first validate the eAIP against its declared DTD (using Xerces a Xerces sample called "sax.Counter", which must be in your classpath).
Simply type "makeaip validator" on a command line.

Edit validator.bat to adapt it to your system: you can use any other validator or XSLT processor.
