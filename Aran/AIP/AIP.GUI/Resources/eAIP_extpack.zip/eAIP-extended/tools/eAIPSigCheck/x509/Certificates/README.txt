Drop in this directory the certificates of the eAIP producers, then run
sigcheck -x509 -import
